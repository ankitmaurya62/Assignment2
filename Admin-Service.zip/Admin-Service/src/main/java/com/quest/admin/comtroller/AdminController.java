package com.quest.admin.comtroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.quest.admin.entity.IssueBook;
import com.quest.admin.response.ResponseTemplate;
import com.quest.admin.service.AdminService;
import com.quest.admin.entity.Library;
import com.quest.admin.entity.Student;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AdminService adminService;


	//Get All Books Records  API's
	@GetMapping("/getAllBookByAdmin")
	public List<Library> getAllBooks(){
		List<Library> book = restTemplate.getForObject("http://localhost:8282/library/getallbooks" ,List.class);
		return book;
	}
      // Get All Student Records API's 
	@GetMapping("/getAllStudentByAdmin")
	public List<Library> getAllStudents(){
		List<Library> students = restTemplate.getForObject("http://localhost:8383/student/getallstudents" ,List.class);
		return students;
	}

	//Register Student By Admin API's
	@PostMapping("/rigisterStudentByAdmin")
	public ResponseEntity<Student> saveStudent(@RequestBody Student student){
		return restTemplate.postForEntity("http://localhost:8383/student/savestudent", student, Student.class);
	}

	// Add Library in Library by Admin API's 
	@PostMapping("/addBookByAdmin")
	public ResponseEntity<Library> saveBook(@RequestBody Library book){
		return restTemplate.postForEntity("http://localhost:8282/library/addbook", book, Library.class);
	}

	// Delete book By Id By the Admin API's
	@DeleteMapping("{id}")
	public void deleteStudent(@PathVariable("id") long studentId) {
		restTemplate.delete("http://localhost:8383/student/" + studentId);

	}

	// Search Library byId By Admin API's 
	@PostMapping("/searchBookByIdByAdmin/{id}")
	public ResponseEntity<String> getBookById(@PathVariable("id") long book){
		return restTemplate.postForEntity("http://localhost:8282/library/getbyid/{id}", book, String.class);
	}
	@DeleteMapping("/book/{id}")
	public void deleteBook(@PathVariable("id") int bookId) {
		restTemplate.delete("http://localhost:8080/api/books/" + bookId);
	}

//	// 8. Filter books by subject.
//	@GetMapping("/searchBook/{subject}")
//	public List<Library> searchBook(@PathVariable("subject") String bookName) {
//		
//		return restTemplate.getForObject("http://localhost:8383/student/searchBySubject/" + bookName, List.class);
//	}
//
	@PostMapping("/addissuebook")
	public IssueBook saveIssueBook(@RequestBody IssueBook issueBook) {
		System.out.println("hiiii");
		return adminService.saveIssueBook(issueBook);
		// return restTemplate.postForEntity("http://localhost:8080/api/books/", book,
		// Book.class);
	}

	@GetMapping("/getIssueBook/{id}")
	public ResponseTemplate getIssueBook(@PathVariable("id") int issueBookId) {
		System.out.println("Hellooooo");
		ResponseTemplate resp = adminService.getIssueBook(issueBookId);

		return resp;

	}

}
