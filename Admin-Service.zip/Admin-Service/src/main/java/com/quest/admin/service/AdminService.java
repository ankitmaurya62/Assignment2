package com.quest.admin.service;

import com.quest.admin.entity.IssueBook;
import com.quest.admin.response.ResponseTemplate;

public interface AdminService {

	public ResponseTemplate getIssueBook(int issueBookId);

	public IssueBook saveIssueBook(IssueBook issueBook);
}