package com.quest.admin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.quest.admin.entity.Library;
import com.quest.admin.entity.IssueBook;
import com.quest.admin.entity.Student;
import com.quest.admin.repository.AdminBookRepository;
import com.quest.admin.response.ResponseTemplate;
import com.quest.admin.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private AdminBookRepository adminBookRepository;

	@Override
	public ResponseTemplate getIssueBook(int issueBookId) {
		ResponseTemplate response = new ResponseTemplate();
		IssueBook issueBook = adminBookRepository.getById(issueBookId);
		Student std = restTemplate.getForObject("http://localhost:8383/student/" + issueBook.getStdId(),
				Student.class);
		Library library = restTemplate.getForObject("http://localhost:8282/library/" + issueBook.getBookId(), Library.class);
		response.setBook(library);
		response.setStudent(std);
		response.setIssueBook(issueBook);
		return response;
	}

	@Override
	public IssueBook saveIssueBook(IssueBook issueBook) {
		// TODO Auto-generated method stub

		return adminBookRepository.save(issueBook);
	}
	

}

