package com.quest.admin.response;

import com.quest.admin.entity.Library;
import com.quest.admin.entity.IssueBook;
import com.quest.admin.entity.Student;

public class ResponseTemplate {

	private Student student;
	private Library library;
	private IssueBook issueBook;

	public ResponseTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResponseTemplate(Student student, Library library, IssueBook issueBook) {
		super();
		this.student = student;
		this.library = library;
		this.issueBook = issueBook;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Library getBook() {
		return library;
	}

	public void setBook(Library library) {
		this.library = library;
	}

	public IssueBook getIssueBook() {
		return issueBook;
	}

	public void setIssueBook(IssueBook issueBook) {
		this.issueBook = issueBook;
	}

	@Override
	public String toString() {
		return "ResponseTemplate [student=" + student + ", library=" + library + ", issueBook=" + issueBook + "]";
	}

}
