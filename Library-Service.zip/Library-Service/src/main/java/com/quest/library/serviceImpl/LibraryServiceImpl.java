package com.quest.library.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quest.library.entity.Library;
import com.quest.library.exception.ResourceNotFoundException;
import com.quest.library.repository.LibraryRepository;
import com.quest.library.service.LibraryService;

@Service
public class LibraryServiceImpl implements LibraryService{

	@Autowired
	private LibraryRepository libraryRepository;


	public LibraryServiceImpl(LibraryRepository libraryRepository) {
		super();
		this.libraryRepository = libraryRepository;
	}

	@Override
	public Library savebook(Library library) {

		return libraryRepository.save(library);
	}

	@Override
	public List<Library> getAllBooks() {

		return libraryRepository.findAll();
	}

	@Override
	public Library getBookById(Long bookId) {

		Optional<Library> book = libraryRepository.findById(bookId);
		
		if(book.isPresent()) {

			return book.get();
		}else {

			throw new ResourceNotFoundException("Book", "bookId", bookId);
		}

	}

	@Override
	public Library updateBook(Library library, long bookId) {



		Library librarys = libraryRepository.findById(bookId).orElseThrow(
				()->new ResourceNotFoundException("Book", "BookId", bookId));

		librarys.setBookName(library.getBookName());
		librarys.setAuthorName(library.getAuthorName());
		librarys.setPrice(library.getPrice());
		libraryRepository.save(library);

		return librarys;
	}

	@Override
	public void deleteBook(long bookId) {


		libraryRepository.findById(bookId).orElseThrow(
				()->new ResourceNotFoundException("Book", "BookId", bookId));

		libraryRepository.deleteById(bookId);
	}
	
	
	
//	@Override
//	public Library getBookByBookName(String bookName) {
//		Library library = libraryRepository.getBookByBookName(bookName);
//		if(library == null) {
//			return library;
//		}
//	
//		return library;
//	}

}

