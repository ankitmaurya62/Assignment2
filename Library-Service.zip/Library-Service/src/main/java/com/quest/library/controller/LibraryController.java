package com.quest.library.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booklibrary.controller.BookSort;
import com.booklibrary.entity.Book;
import com.quest.library.entity.Library;
import com.quest.library.repository.LibraryRepository;
import com.quest.library.service.LibraryService;

/*
 * Spring 4.0 introduced the @RestController annotation 
 * in order to simplify the creation of RESTful web services.
 *  It's a convenient annotation that combines @Controller and @ResponseBody,
 *   which eliminates the need to annotate every request handling method of the 
 *   controller class with the @ResponseBody annotation.
 */
@RestController
@RequestMapping("/library")
public class LibraryController {

	@Autowired
	private LibraryService libraryService;
    
	@Autowired
    private LibraryRepository libraryRepository;

	public LibraryController(LibraryService libraryService) {
		super();
		this.libraryService = libraryService;
	}

	//build Add book in Library API's
	@PostMapping("/addbook")
	public ResponseEntity<Library>savebook(@RequestBody Library book){
		return new ResponseEntity<Library>(libraryService.savebook(book), HttpStatus.CREATED);
	}


	//build get all books from Library API's
	@GetMapping("/getallbooks")

	public List<Library> getAllBooks(){
		return libraryService.getAllBooks();
	}


	//build get BookById from Library API's
	@GetMapping("/getbyid/{id}")
	public ResponseEntity<Library> getBookById(@PathVariable("id") long bookId){
		return new ResponseEntity<Library>(libraryService.getBookById(bookId),HttpStatus.OK);
	}


	//build UpdateBookById from Library API's
	@PutMapping("/updatebyid/{id}")
	public ResponseEntity<Library> updateBook(@PathVariable("id") long bookId, @RequestBody Library book){
		return new ResponseEntity<Library>(libraryService.updateBook(book, bookId),HttpStatus.OK);
	}


	//build DeleteBookById from Library API's
	@DeleteMapping("deleteById/{id}")
	public ResponseEntity<String> deleteBook(@PathVariable("id") long bookId){

		libraryService.deleteBook(bookId);
		return new ResponseEntity<String>("Book deleted successfully!!", HttpStatus.OK);
	}
	//7. Sort the book details and search for them. (you are free to cho0se the search criteria)
	// search Book by subject-wise
//	@GetMapping("/searchBySubject/{subject}")
//	public List<Library> searchBookByName(@PathVariable(value = "subject") String bookName) {
//		List<Library> bookList = this.libraryRepository.findByBookName(bookName);
//		return bookList;
//	}
//
//	// Sorted by Book Name
//	@GetMapping("/sortedByBookName")
//	public List<Library> getSortedBookName() {
//		List<Library> listBook = libraryRepository.findAll();
//		Collections.sort(listBook, new BookSort());
//		return listBook;
//
//	}
}
