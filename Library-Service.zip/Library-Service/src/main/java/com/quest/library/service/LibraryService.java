package com.quest.library.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.quest.library.entity.Library;

/*Spring @Service annotation is a specialization of
 *  @Component annotation. Spring Service annotation can be applied only to classes.
 *   It is used to mark the class as a service provider.*/

@Service
public interface LibraryService{

	Library savebook(Library library);

	List<Library> getAllBooks();

	Library getBookById(Long bookId);

	Library updateBook(Library library, long bookId);

	void deleteBook(long bookId);
	


}
