package com.quest.library.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * It contains dependencies for Freemaker, Spring Data JPA, and H2 database. 
 * When Spring Boot finds Freemaker and H2 in the pom. ... 
 * The @Entity annotation specifies that the class is an entity and is mapped to a database table. 
 * The @Table annotation specifies the name of the database table to be used for mapping
 * */

@Entity
@Table(name = "book")

public class Library {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)


	@Column(name="book_id")
	private Long bookId;
	
	@Column(name="book_name")
	private String bookName;

	@Column(name="author_name")
	private String authorName;

	@Column(name="book_price")
	private float price;

	public Long getBookId() {
		return bookId;
	}

	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

}