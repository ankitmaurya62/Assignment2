package com.quest.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpServerErrorException;

import com.quest.library.controller.LibraryController;
import com.quest.library.entity.Library;
import com.quest.library.service.LibraryService;

@RunWith(SpringRunner.class)
public class LibraryControllerTest {
	@InjectMocks
	LibraryController libraryController;

	@Mock
	LibraryService libraryService;

	@Test
	public void savebooktest() {
		Library lLibrary=new Library();
		lLibrary.setBookName("java");
		ResponseEntity<Library> res=libraryController.savebook(lLibrary);
		assertNotNull(res);
		assertEquals("java",lLibrary.getBookName());
	}
	@Test
	public void getbooktest() {
		Library lLibrary=new Library();
		lLibrary.setBookName("php");
		lLibrary.getBookName();
		List<Library> res=libraryController.getAllBooks();
		assertNotNull(res);
		assertEquals("php",lLibrary.getBookName());
	}

}
