package com.quest.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.PageAttributes.MediaType;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.quest.student.controller.StudentController;
import com.quest.student.entity.Student;
import com.quest.student.service.StudentService;

@RunWith(SpringRunner.class)
public class StudentControllerTest {
	@InjectMocks
	StudentController studentController;

	@Mock
	StudentService studentService;

	@Test
public void addstudenttest() {
	Student lstudent=new Student();
	lstudent.setStudentName("Ankit");
	ResponseEntity<Student> res=studentController.savestudent(lstudent);
	assertNotNull(res);
	assertEquals("Ankit",lstudent.getStudentName());
}
	@Test
	public void getstudenttest() {
		Student lstudent=new Student();
		lstudent.setStudentName("Rishu");
		lstudent.getStudentName();
		List<Student> res=studentController.getAllStudents();
		assertNotNull(res);
		assertEquals("Rishu",lstudent.getStudentName());
	}
	
	@Test
	public void updateStudent() throws Exception {
	   String uri = "/student/updatebyid/{id}/2";
	   Student student = new Student();
	   student.setStudentName("Rishu");
	   
	   //String inputJson = super.mapToJson(student);
	  // MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.put(uri)
	     // .contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson)).andReturn();
	   
	   //int status = set.getResponse().getStatus();
	   //assertEquals(200, status);
	   //String content = mvcResult.getResponse().getContentAsString();
	  // assertEquals(content, "Product is updated successsfully");
	}
	
}
