package com.quest.student.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/*
 * It contains dependencies for Freemaker, Spring Data JPA, and H2 database. 
 * When Spring Boot finds Freemaker and H2 in the pom. ... 
 * The @Entity annotation specifies that the class is an entity and is mapped to a database table. 
 * The @Table annotation specifies the name of the database table to be used for mapping
 * */

@Entity
@Table(name = "student")

public class Student {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)


	@Column(name="student_id")
	private Long studentId;

	@Column(name="student_name")
	private String studentName;

	@Column(name="email_id")
	private String emailId;

	@Column(name="roll_Number")
	private float rollNumber;
	
	
	public Long getStudentId() {
		return studentId;
	}

	public void setStudentId(Long studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public float getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(float rollNumber) {
		this.rollNumber = rollNumber;
	}


}