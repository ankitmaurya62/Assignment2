package com.quest.student;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*Spring Boot @SpringBootApplication annotation is used to
mark a configuration class that declares one or more @Bean 
methods and also triggers auto-configuration and component scanning. 
 *
 */
@SpringBootApplication
public class StudentServiceApplication {

	//Main Method
	public static void main(String[] args) {
		SpringApplication.run(StudentServiceApplication.class, args);
	}

}
