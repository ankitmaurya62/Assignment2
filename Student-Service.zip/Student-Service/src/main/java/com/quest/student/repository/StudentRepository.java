package com.quest.student.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.quest.student.entity.Student;

/*
 * The Spring @Repository annotation is a specialization of the 
 * @Component annotation which indicates that an annotated class is 
 * a “Repository”, which can be used as a mechanism for encapsulating storage,
 *  retrieval, and search behavior which emulates a collection of objects.
 * */
@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

}
