package com.quest.student.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.quest.student.entity.Student;

/*Spring @Service annotation is a specialization of
 *  @Component annotation. Spring Service annotation can be applied only to classes.
 *   It is used to mark the class as a service provider.*/

@Service
public interface StudentService{

	Student savestudent(Student student);

	List<Student> getAllStudents();

	Student getStudentById(Long studentId);

	Student updateStudent(Student student, long studentId);

	void deleteStudent(long studentId);

}
