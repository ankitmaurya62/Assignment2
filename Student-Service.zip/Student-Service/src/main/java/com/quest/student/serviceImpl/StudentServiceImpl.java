package com.quest.student.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quest.student.entity.Student;
import com.quest.student.exception.ResourceNotFoundException;
import com.quest.student.repository.StudentRepository;
import com.quest.student.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentRepository studentRepository;


	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	@Override
	public Student savestudent(Student student) {

		return studentRepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {

		return studentRepository.findAll();
	}

	@Override
	public Student getStudentById(Long studentId) {

		Optional<Student> student = studentRepository.findById(studentId);

		return studentRepository.findById(studentId).orElseThrow(()->new ResourceNotFoundException("Student", "StudentID", studentId));

	}

	@Override
	public Student updateStudent(Student student, long studentId) {



		Student existingStudent = studentRepository.findById(studentId).orElseThrow(
				()->new ResourceNotFoundException("student", "StudentId", studentId));

		existingStudent.setStudentName(student.getStudentName());
		existingStudent.setEmailId(student.getEmailId());
		existingStudent.setRollNumber(student.getRollNumber());

		studentRepository.save(existingStudent);

		return existingStudent;
	}

	@Override
	public void deleteStudent(long studentId) {


		studentRepository.findById(studentId).orElseThrow(
				()->new ResourceNotFoundException("Student", "StudentId", studentId));

		studentRepository.deleteById(studentId);
	}

}

